<?php

namespace App;

use Spatie\Valuestore\Valuestore;

class Settings extends Valuestore
{
    //
}
