@extends('layouts.app')

@section('title','Register')

@section('content')
<register-component name="{{ env('APP_NAME') }}"></register-component>
@endsection
