<footer class="main-footer">
    <!-- To the right -->
    <div class="float-right d-none d-sm-inline">
        <strong> Developed & <i class="far fa-heart"></i> by </strong>
        <a target="_blank" href="https://programmingkit.net">Programming Kit</a>
    </div>
    <!-- Default to the left -->
    <strong>Copyright &copy; {{ now()->year }} {{ settings('application_name') }}.</strong> All rights reserved.
</footer>
