<?php $__env->startSection('title','Profile'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Profile</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item active">Profile</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-3">

            <!-- Profile Image -->
            <div class="card card-primary card-outline">
              <div class="card-body box-profile">
                <div class="text-center">
                  <img class="profile-user-img img-fluid img-circle"
                       src="<?php echo e(Storage::disk('public')->url('users/'.auth()->user()->image)); ?>"
                       alt="User profile picture">
                </div>

                <h3 class="profile-username text-center"><?php echo e(auth()->user()->name); ?></h3>

                <?php $__currentLoopData = auth()->user()->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="text-muted text-center"><?php echo e($role->name); ?></p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <ul class="list-group list-group-unbordered mb-3">
                  <li class="list-group-item">
                    <b>Status</b>
                    <div class="float-right">
                        <?php if(auth()->user()->status === \App\Enums\UserStatus::Active): ?>
                            <span class="badge badge-info"><?php echo e(\App\Enums\UserStatus::getKey(auth()->user()->status)); ?></span>
                        <?php else: ?>
                            <span class="badge badge-danger"><?php echo e(\App\Enums\UserStatus::getKey(auth()->user()->status)); ?></span>
                        <?php endif; ?>
                    </div>
                  </li>
                  <li class="list-group-item">
                    <b>Username</b> <a class="float-right"><?php echo e(auth()->user()->username); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Email</b> <a class="float-right"><?php echo e(auth()->user()->email); ?></a>
                  </li>
                  <li class="list-group-item">
                    <b>Joined At</b> <a class="float-right"><?php echo e(auth()->user()->created_at->diffForHumans()); ?></a>
                  </li>
                </ul>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-md-9">
            <div class="card card-info card-outline">
              <div class="card-body">
                  <form action="<?php echo e(route('users.profile.update')); ?>" method="POST" class="form-horizontal" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label for="name" class="col-sm-12 control-label">Name</label>
                        <div class="col-sm-12">
                            <input type="text" class="form-control" id="name" name="name" placeholder="Enter full name" value="<?php echo e(auth()->user()->name); ?>" required>
                        </div>
                      </div>


                      <div class="form-group">
                        <label class="col-sm-12 control-label" for="image">Image
                            <span class="required-field">*</span>
                            <span class="help">e.g. "Image" (png, jpg)</span>
                        </label>

                        <div class="col-sm-12">
                            <input type="file" name="image" id="image" class="dropify <?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>">
                            <?php if($errors->has('image')): ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($errors->first('image')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                          <button type="submit" class="btn btn-info">Update</button>
                        </div>
                      </div>
                    </form>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>