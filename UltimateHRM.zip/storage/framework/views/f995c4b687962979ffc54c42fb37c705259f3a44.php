<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>HRM - The Ultimate HRM</title>
    <link rel="icon" href="<?php echo e(asset('/favicon.png')); ?>" type="image/x-icon">
    <!-- // CSS FILES // -->
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <!-- OWl Carousel CSS Files -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.theme.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.transitions.min.css">
    <!-- ANIMATE CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.0/animate.min.css">
    <!-- PRELOADER -->
    <link rel="stylesheet" href="<?php echo e(asset('landing/css/preloader.css')); ?>">
    <!-- Main CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('landing/css/style.css')); ?>">
</head>

<body data-spy="scroll" data-target=".navbar">

    <!-- ==============================================
    PRELOADER
    =============================================== -->

    <div class="preloader-holder">
        <div class="loading">
            <div class="finger finger-1">
                <div class="finger-item">
                    <span></span><i></i>
                </div>
            </div>
            <div class="finger finger-2">
                <div class="finger-item">
                    <span></span><i></i>
                </div>
            </div>
            <div class="finger finger-3">
                <div class="finger-item">
                    <span></span><i></i>
                </div>
            </div>
            <div class="finger finger-4">
                <div class="finger-item">
                    <span></span><i></i>
                </div>
            </div>
            <div class="last-finger">
                <div class="last-finger-item"><i></i></div>
            </div>
        </div>
    </div>

    <!-- ==============================================
    HEADER
    =============================================== -->

    <header id="home">

        <!-- /// Navbar /// -->

        <nav class="navbar navbar-expand-lg fixed-top">
            <div class="container">
                <!-- // Brand // -->

                <a class="navbar-brand" href="#">The Ultimate <span>HRM</span></a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation"><i class="material-icons">menu</i></button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <!-- / NavLinks / -->

                    <ul class="nav navbar-nav ml-auto">
                        <li class="nav-item">
                            <a class="nav-link page-scroll" href="#home">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link page-scroll" href="#screenshots">Screenshots</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link page-scroll" href="#contact">Contact</a>
                        </li>
                        <li>
                            <?php if(auth()->guard()->check()): ?>
                                <a href="<?php echo e(route('dashboard')); ?>"><button class="btn btn-primary">Dashboard</button></a>
                            <?php else: ?>
                                <a href="<?php echo e(route('login')); ?>"><button class="btn btn-primary">Sign In</button></a>
                            <?php endif; ?>
                        </li>
                    </ul>

                </div>
            </div>
        </nav>

        <!-- /// BANNER /// -->
        <div class="banner">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 offset-md-2">
                        <!-- // Caption // -->
                        <div class="caption">
                            <h1>Make Business Easy With The Ultimate HRM.</h1>
                            <p class="sub">Complete Human Resource Management System at your fingertips.</p>
                            <a class="btn btn-primary" href="#">Buy Now</a>
                            <!-- / Macbook IMG / -->
                            <img class="img-fluid mx-auto wow fadeInUp" data-wow-duration="1s" data-wow-delay=".3s" src="/landing/imgs/macbook.png" alt="macbook">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- ==============================================
    ABOUT
    =============================================== -->

    <section id="about">
        <div class="container">
            <div class="row">
                <div class="col-md-4 wow bounceIn" data-wow-duration=".5s" data-wow-delay=".2s">
                    <!-- /// Icon /// -->
                    <i data-vi="layers" data-vi-size="70" data-vi-primary="#1992ec" data-vi-accent="#daeffd" data-vi-prop="#CEFAFF"></i>
                    <!-- // Title // -->
                    <h4>Creative Design</h4>
                    <!-- / Caption / -->
                    
                </div>
                <div class="col-md-4 wow bounceIn" data-wow-duration=".5s" data-wow-delay=".4s">
                    <!-- /// Icon /// -->
                    <i data-vi="website" data-vi-size="70" data-vi-primary="#1992ec" data-vi-accent="#daeffd" data-vi-prop="#CEFAFF"></i>
                    <!-- // Title // -->
                    <h4>Fully Responsive</h4>
                </div>
                <div class="col-md-4 wow bounceIn" data-wow-duration=".5s" data-wow-delay=".6s">
                    <!-- /// Icon /// -->
                    <i data-vi="chat" data-vi-size="70" data-vi-primary="#1992ec" data-vi-accent="#daeffd" data-vi-prop="#CEFAFF"></i>
                    <!-- // Title // -->
                    <h4>Unlimited Support</h4>
                </div>
            </div>
        </div>
    </section>

    <!-- ==============================================
    FEATURES
    =============================================== -->

    

    <!-- ==============================================
    TESTIMONIALS
    =============================================== -->

   

    <!-- ==============================================
    PRICING
    =============================================== -->

    



    <!-- ==============================================
    APP SCREENSHOTS
    =============================================== -->

    <section id="screenshots">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-sm-offset-2 col-md-offset-3 text-center title-container">
                    <!-- /// Title /// -->
                    <h2 class="section-title">App Screenshots:</h2>
                </div>
            </div>
            <div class="row">
                <div id="owl-screenshots">
                    <div class="item"><img src="/landing/imgs/screenshots/1.png" class="img-fluid" alt="screen-1"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/2.png" class="img-fluid" alt="screen-2"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/3.png" class="img-fluid" alt="screen-3"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/4.png" class="img-fluid" alt="screen-4"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/5.png" class="img-fluid" alt="screen-5"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/6.png" class="img-fluid" alt="screen-6"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/7.png" class="img-fluid" alt="screen-7"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/8.png" class="img-fluid" alt="screen-8"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/9.png" class="img-fluid" alt="screen-9"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/10.png" class="img-fluid" alt="screen-10"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/11.png" class="img-fluid" alt="screen-11"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/12.png" class="img-fluid" alt="screen-12"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/13.png" class="img-fluid" alt="screen-13"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/14.png" class="img-fluid" alt="screen-14"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/15.png" class="img-fluid" alt="screen-15"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/16.png" class="img-fluid" alt="screen-16"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/17.png" class="img-fluid" alt="screen-17"></div>
                    <div class="item"><img src="/landing/imgs/screenshots/18.png" class="img-fluid" alt="screen-18"></div>
                </div>
            </div>
        </div>
    </section>

    <!-- ==============================================
    VIDEO POP UP
    =============================================== -->

    

    <!-- ==============================================
    TEAM
    =============================================== -->



    <!-- ==============================================
    BRAND
    =============================================== -->

   

    <!-- ==============================================
    FOOTER
    =============================================== -->

    <section id="contact">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-8 col-md-6 col-sm-offset-2 col-md-offset-3 text-center title-container">
                    <!-- /// Title /// -->
                    <h2 class="section-title">Don't Be Shy Send a Message:</h2>
                    <p>If you have any question feel free to contact us.</p>
                </div>
            </div>

            <!-- /// CONTACT FORMS /// -->

            <form action="https://formspree.io/cipfahim1999@gmail.com" method="POST">
                <div class="form-row">
                    <div class="form-group col-xs-12 col-sm-4">
                        <label>Name:</label>
                        <input type="text" class="form-control" id="inputName4" name="name">
                    </div>
                    <div class="form-group col-xs-12 col-sm-4">
                        <label for="inputPassword4">Email:</label>
                        <input type="email" class="form-control" id="inputPassword4" name="email">
                    </div>
                    <div class="form-group col-xs-12 col-sm-4">
                        <label>Phone:</label>
                        <input type="text" class="form-control" id="inputPhone" name="phone">
                    </div>
                </div>
                <div class="form-group">
                    <label>Subject:</label>
                    <input type="text" class="form-control" id="inputSubject" name="subject">
                </div>
                <div class="form-group">
                    <label>Message:</label>
                    <textarea id="form-message" cols="30" rows="5" class="form-control" name="message"></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Send Message</button>
            </form>
            <p><strong>Copyright &copy; <?php echo e(now()->year); ?> <?php echo e(settings('application_name')); ?>.</strong> All rights reserved. <strong> Developed & <i class="far fa-heart"></i> by </strong>
        <a target="_blank" href="https://programmingkit.net">Programming Kit</a></p>
        </div>
    </section>

    <!-- Scripts -->
    <!-- jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <!-- Popper.js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <!-- Icons -->
    <script src="https://cdn.jsdelivr.net/npm/vivid-icons"></script>
    <script src="https://unpkg.com/vivid-icons"></script>
    <!-- OWL Carousel -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
    <!-- Easing -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.4.1/jquery.easing.min.js"></script>
    <!-- Main JS -->
    <script src="<?php echo e(asset('landing/js/main.js')); ?>"></script>
</body>
</html>
