<?php $__env->startSection('title','Dashboard'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark">Dashboard</h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item active">Dashboard</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-info">
                        <?php if(!auth()->check() || ! auth()->user()->hasRole('employee')): ?>
                            <div class="inner">
                                <h3><?php echo e($employeesCount); ?></h3>
                                <p>Total <br> <strong>Employees</strong></p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-user-tie"></i>
                            </div>
                            <a href="<?php echo e(route('employees.index')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                        <?php else: ?>
                            <div class="inner">
                                <h3><?php echo e($awardsCount); ?></h3>
                                <p>This Month <br> <strong>Awards</strong></p>
                            </div>
                            <div class="icon">
                               <i class="fas fa-award"></i>
                            </div>
                            <a href="<?php echo e(route('employees.index')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                        <?php endif; ?>
                    </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-success">
                    <div class="inner">
                        <h3><?php echo e($leaveApplicationCount); ?></h3>
                        <p>This Month <br> <strong>Leave Application</strong></p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-poll-h"></i>
                    </div>
                    <a href="<?php echo e(route('leave.applications.index')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-warning">
                    <div class="inner">
                        <h3><?php echo e($expenseCount); ?></h3>
                        <p>This Month <br> <strong>Expense Request</strong></p>
                    </div>
                    <div class="icon">
                        <i class="far fa-credit-card"></i>
                    </div>
                    <a href="<?php echo e(route('expenses.index')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-3 col-6">
                    <!-- small box -->
                    <div class="small-box bg-danger">
                    <div class="inner">
                       <h3><?php echo e($eventsCount); ?></h3>
                       <p>This Month <br> <strong>Events & Holidays</strong></p>
                    </div>
                    <div class="icon">
                        <i class="fas fa-calendar-week"></i>
                    </div>
                    <a href="<?php echo e(Auth::user()->hasRole('employee') ? route('events.calendar') : route('events.index')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
                <!-- ./col -->
            </div>
            <div class="row">
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="info-box">
                        <?php if(!auth()->check() || ! auth()->user()->hasRole('employee')): ?>
                        <span class="info-box-icon bg-info elevation-1">
                            <i class="fas fa-code-branch"></i>
                        </span>

                        <div class="info-box-content">
                            <a href="<?php echo e(route('branches.index')); ?>" class="text-decoration-none text-dark">
                                <span class="info-box-text">Branches</span>
                            </a>
                            <span class="info-box-number"><?php echo e($branchesCount); ?></span>
                        </div>
                        <?php else: ?>
                        <span class="info-box-icon bg-info elevation-1">
                            <i class="fas fa-calendar-day"></i>
                        </span>

                        <div class="info-box-content">
                            <a href="<?php echo e(route('branches.index')); ?>" class="text-decoration-none text-dark">
                                <span class="info-box-text">This Month</span>
                                <span class="info-box-text">Total Working Day</span>
                            </a>
                            <span class="info-box-number"><?php echo e($totalDays); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="info-box mb-3">
                        <?php if(!auth()->check() || ! auth()->user()->hasRole('employee')): ?>
                            <span class="info-box-icon bg-danger elevation-1">
                                <i class="fas fa-project-diagram"></i>
                            </span>

                            <div class="info-box-content">
                                <a href="<?php echo e(route('departments.index')); ?>" class="text-decoration-none text-dark">
                                    <span class="info-box-text">Departments</span>
                                </a>
                                <span class="info-box-number"><?php echo e($departmentsCount); ?></span>
                            </div>
                        <?php else: ?>
                            <span class="info-box-icon bg-danger elevation-1">
                                <i class="fas fa-user-check"></i>
                            </span>

                            <div class="info-box-content">
                                <a href="<?php echo e(route('departments.index')); ?>" class="text-decoration-none text-dark">
                                    <span class="info-box-text">This Month</span>
                                    <span class="info-box-text">Total Present Day</span>
                                </a>
                                <span class="info-box-number"><?php echo e($totalPresent); ?></span>
                            </div>
                        <?php endif; ?>

                    <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->

                <!-- fix for small devices only -->
                <div class="clearfix hidden-md-up"></div>

                <div class="col-12 col-sm-6 col-md-3">
                    <div class="info-box mb-3">
                        <?php if(!auth()->check() || ! auth()->user()->hasRole('employee')): ?>
                            <span class="info-box-icon bg-success elevation-1">
                                <i class="fas fa-sticky-note"></i>
                            </span>

                            <div class="info-box-content">
                            <a href="<?php echo e(route('noticeboard.index')); ?>" class="text-decoration-none text-dark">
                                    <span class="info-box-text">This Month Notice</span>
                                </a>
                                <span class="info-box-number"><?php echo e($noticeCount); ?></span>
                            </div>
                        <?php else: ?>
                            <span class="info-box-icon bg-success elevation-1">
                                <i class="fas fa-user-times"></i>
                            </span>

                            <div class="info-box-content">
                            <a href="<?php echo e(route('noticeboard.index')); ?>" class="text-decoration-none text-dark">
                                    <span class="info-box-text">This Month</span>
                                    <span class="info-box-text">Total Absence</span>
                                </a>
                                <span class="info-box-number"><?php echo e($totalAbsence); ?></span>
                            </div>
                        <?php endif; ?>

                    <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->
                <div class="col-12 col-sm-6 col-md-3">
                    <div class="info-box mb-3">
                        <?php if(!auth()->check() || ! auth()->user()->hasRole('employee')): ?>
                            <span class="info-box-icon bg-warning elevation-1">
                                <i class="fas fa-award"></i>
                            </span>

                            <div class="info-box-content">
                                <a href="<?php echo e(route('awards.index')); ?>" class="text-decoration-none text-dark">
                                    <span class="info-box-text">This Month Awards</span>
                                </a>
                                <span class="info-box-number"><?php echo e($awardsCount); ?></span>
                            </div>
                        <?php else: ?>
                            <span class="info-box-icon bg-warning elevation-1">
                                <i class="fas fa-user-slash"></i>
                            </span>

                            <div class="info-box-content">
                                <a href="<?php echo e(route('awards.index')); ?>" class="text-decoration-none text-dark">
                                    <span class="info-box-text">This Month</span>
                                    <span class="info-box-text">Total Leave</span>
                                </a>
                                <span class="info-box-number"><?php echo e($totalLeave); ?></span>
                            </div>
                        <?php endif; ?>

                    <!-- /.info-box-content -->
                    </div>
                    <!-- /.info-box -->
                </div>
                <!-- /.col -->
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="card">
                        <div class="card-header no-border">
                            <div class="d-flex justify-content-between">
                            <h3 class="card-title">Expenses analytics</h3>
                            </div>
                        </div>
                        <div class="card-body" id="expense-chart">

                        </div>
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col-md-6 -->
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header border-transparent">
                            <h3 class="card-title">Recent Leave Application</h3>

                            <div class="card-tools">
                            <button type="button" class="btn btn-tool" data-widget="collapse">
                                <i class="fa fa-minus"></i>
                            </button>
                            <button type="button" class="btn btn-tool" data-widget="remove">
                                <i class="fa fa-times"></i>
                            </button>
                            </div>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body p-0">
                            <div class="table-responsive">
                            <table class="table m-0">
                                <thead>
                                <tr>
                                <th>#</th>
                                <th>Employee Name</th>
                                <th>Leave Type</th>
                                <th>Status</th>
                                <th>Received At</th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $recentLeaveApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$leaveApplication): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($leaveApplication->employee->user->name ?? 'Not Found'); ?></td>
                                    <td><?php echo e($leaveApplication->type->name ?? 'Not Found'); ?></td>
                                    <td>
                                        <?php if($leaveApplication->status == \App\Enums\LeaveStatus::Approved): ?>
                                            <span class="badge badge-primary">
                                                <?php echo e(\App\Enums\LeaveStatus::getKey($leaveApplication->status)); ?>

                                            </span>

                                        <?php else: ?>
                                                <span class="badge badge-danger">
                                                <?php echo e(\App\Enums\LeaveStatus::getKey($leaveApplication->status)); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($leaveApplication->created_at->diffForHumans()); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr class="text-center">
                                            <td colspan="5"><strong>No Data found.</strong></td>
                                        </tr>
                                    <?php endif; ?>

                                </tbody>
                            </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
                        <!-- /.card-body -->
                        <div class="card-footer clearfix">
                            <a href="<?php echo e(route('leave.applications.create')); ?>" class="btn btn-sm btn-info float-left">Create New</a>
                            <a href="<?php echo e(route('leave.applications.index')); ?>" class="btn btn-sm btn-secondary float-right">View All Applications</a>
                        </div>
                        <!-- /.card-footer -->
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card">
              <div class="card-header border-transparent">
                <h3 class="card-title">Recent Expense Request</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-widget="collapse">
                    <i class="fa fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-widget="remove">
                    <i class="fa fa-times"></i>
                  </button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body p-0">
                <div class="table-responsive">
                    <table class="table m-0">
                        <thead>
                        <tr>
                        <th>#</th>
                        <th>Purchase By</th>
                        <th>Amount</th>
                        
                        <th>Status</th>
                        <th>Received At</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $recentExpenseRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$expenseRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                            <td><?php echo e($key + 1); ?></td>
                            <td><?php echo e($expenseRequest->employee->user->name ?? 'Not Found'); ?></td>
                            <td><?php echo e($expenseRequest->amount); ?></td>
                            
                            <td>
                                <?php if($expenseRequest->status == \App\Enums\ExpenseStatus::Approved): ?>
                                    <span class="badge badge-primary">
                                        <?php echo e(\App\Enums\ExpenseStatus::getKey($expenseRequest->status)); ?>

                                    </span>

                                <?php else: ?>
                                        <span class="badge badge-danger">
                                        <?php echo e(\App\Enums\ExpenseStatus::getKey($expenseRequest->status)); ?>

                                    </span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($expenseRequest->created_at->diffForHumans()); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr class="text-center">
                                    <td colspan="5"><strong>No Data found.</strong></td>
                                </tr>
                            <?php endif; ?>

                        </tbody>
                    </table>
                </div>
                <!-- /.table-responsive -->
            </div>
              <!-- /.card-body -->
              <div class="card-footer clearfix">
                <a href="<?php echo e(route('expenses.create')); ?>" class="btn btn-sm btn-info float-left">Add New Expense</a>
                <a href="<?php echo e(route('expenses.index')); ?>" class="btn btn-sm btn-secondary float-right">View All Expenses</a>
              </div>
              <!-- /.card-footer -->
            </div>
                </div>
            </div>

        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/series-label.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>
<script src="https://code.highcharts.com/modules/export-data.js"></script>

<script>
Highcharts.chart('expense-chart', {
    chart: {
        type: 'spline'
    },
    title: {
        text: 'Monthly Expenses'
    },
    xAxis: {
        categories: [
            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            // 'Jan',
            '<?php echo e(\App\Enums\Month::getKey((int)$expense->month)); ?>-<?php echo e($expense->year); ?>',
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]
    },
    yAxis: {
        title: {
            text: 'Expense Amount'
        },
        labels: {
            formatter: function () {
                return this.value + '$';
            }
        }
    },
    tooltip: {
        crosshairs: true,
        shared: true
    },
    plotOptions: {
        spline: {
            marker: {
                radius: 4,
                lineColor: '#666666',
                lineWidth: 1
            }
        }
    },
    series: [{
        name: 'Expense',
        marker: {
            symbol: 'round'
        },
        data: [
            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($expense->total_expense); ?>,
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ]

    }]
});
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>