<nav class="main-header navbar navbar-expand border-bottom navbar-dark bg-primary bg-gradient-blue">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
        </li>
    </ul>
    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
        <!-- Notifications Dropdown Menu -->
        <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
                <i class="far fa-bell fa-2x"></i>
                <?php if(auth()->user()->unreadNotifications->count() > 0): ?>
                    <span class="badge badge-warning navbar-badge"><?php echo e(auth()->user()->unreadNotifications->count()); ?></span>
                <?php endif; ?>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                <?php if(auth()->user()->unreadNotifications->count() > 0): ?>
                    <span class="dropdown-header"><?php echo e(auth()->user()->unreadNotifications->count()); ?> Notifications</span>
                    <div class="dropdown-divider"></div>
                <?php endif; ?>


                <?php $__empty_1 = true; $__currentLoopData = auth()->user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <a href="<?php echo e($notification->data['action']); ?>" class="dropdown-item">
                    <?php echo e(str_limit($notification->data['title'], 20)); ?>

                    <span class="float-right text-muted text-sm"><?php echo e($notification->created_at->diffForHumans()); ?></span>
                </a>
                <div class="dropdown-divider"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <span class="dropdown-header">All caught up!</span>
                <?php endif; ?>

                <a href="<?php echo e(route('notifications.index')); ?>" class="dropdown-item dropdown-footer">See All Notifications</a>
            </div>
        </li>
        <!-- profile Dropdown Menu -->
        <li class="nav-item dropdown">
            <a class="nav-link" data-toggle="dropdown" href="#">
                <i class="fas fa-user-circle fa-2x"></i>
            </a>
            <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                <span class="dropdown-header"><?php echo e(Auth::user()->name); ?></span>
                <div class="dropdown-divider"></div>
                <a href="<?php echo e(route('users.profile')); ?>" class="dropdown-item">
                    <i class="fa fa-user mr-2"></i> Profile
                </a>
                <a href="<?php echo e(route('users.password.change')); ?>" class="dropdown-item">
                    <i class="fa fa-key mr-2"></i> Change Password
                </a>
                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                    <?php if(Auth::user()->hasPermissionTo('settings.index')): ?>
                        <a  href="<?php echo e(route('settings.index')); ?>" class="dropdown-item">
                            <i class="fas fa-cog mr-2"></i> Settings
                        </a>
                    <?php endif; ?>
                <?php endif; ?>
                <div class="dropdown-divider"></div>
                <a onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();" href="<?php echo e(route('logout')); ?>" class="dropdown-item">
                    <i class="fa fa-lock mr-2"></i> Logout
                </a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </li>
    </ul>
</nav>
