<?php $__env->startSection('title','Role'); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Roles</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                        <li class="breadcrumb-item active">Roles</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-12">
                <div class="card card-primary card-outline">
                    <div class="card-header">
                        <h3 class="card-title">All Roles.</h3>
                        <div class="card-tools">
                            <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary">
                                <i class="fas fa-plus-circle"></i>
                                <span>Create New</span>
                            </a>
                        </div>
                    </div>

                    <!-- /.card-header -->
                    <div class="card-body table-responsive p-0">
                        <table id="datatable" class="table table-hover">
                            <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th class="text-center">Permissions</th>
                                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                <th>Last Modified</th>
                                <?php endif; ?>
                                <th class="text-center">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($key + 1); ?></td>
                                    <td><?php echo e($role->name); ?></td>
                                    <td class="text-center">
                                        <?php if($role->permissions->count() > 0): ?>
                                            <span class="badge badge-info"><?php echo e($role->permissions->count()); ?></span>
                                        <?php else: ?>
                                            <span class="badge badge-danger">No permission found :(</span>

                                        <?php endif; ?>
                                    </td>
                                    <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                    <td><?php echo e($role->updated_at); ?></td>
                                    <?php endif; ?>
                                    <td class="text-center">
                                        <a class="btn btn-info btn-sm" href="<?php echo e(route('roles.edit',$role->id)); ?>"><i class="fas fa-edit"></i></a>
                                        <button type="button" class="btn btn-danger btn-sm" onclick="deleteData(<?php echo e($role->id); ?>)"><i class="fas fa-trash-alt"></i></button>
                                        <form id="delete-form-<?php echo e($role->id); ?>" action="<?php echo e(route('roles.destroy',$role->id)); ?>" method="POST" style="display: none;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th class="text-center">Permissions</th>
                                <?php if(auth()->check() && auth()->user()->hasRole('admin')): ?>
                                <th>Last Modified</th>
                                <?php endif; ?>
                                <th class="text-center">Action</th>
                            </tr>
                            </tfoot>
                        </table>
                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
    <script>
        $(function () {
            $("#datatable").DataTable();
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>